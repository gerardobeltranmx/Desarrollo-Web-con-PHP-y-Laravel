<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
     <title>Document</title>
</head>
<body>
<h3> Lista de Cuentas </h3>

<a href="cuentas/nuevo">Nueva Cuenta</a>
<table class='table table-striped' >
   <tr>
       <th>Id</th>
       <th>Nombre</th>
       <th>correo</th>
       <th></th>
       <th></th>
       <th></th>

    </tr>

    <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
        <td><?php echo e($cuenta->id); ?></td> 
        <td><?php echo e($cuenta->nombre); ?></td> 
        <td><?php echo e($cuenta->correo); ?></td> 
        <td> <a href="cuentas/detalle/<?php echo e($cuenta->id); ?>">Detalle</a></td> 
        <td> <a href="cuentas/editar/<?php echo e($cuenta->id); ?>">Editar</a></td> 
        <td> <a href="cuentas/eliminar/<?php echo e($cuenta->id); ?>">Eliminar</a></td> 
        <td> <a href="movimientos/retiro/<?php echo e($cuenta->id); ?>">Retirar</a></td> 
        <td> <a href="movimientos/depositos/<?php echo e($cuenta->id); ?>">Depositar</a></td> 

        
                                   
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </table> 

</body>
</html><?php /**PATH /home/gerardo/GIT/Desarrollo-Web-con-PHP-y-Laravel/laravel/bancos/resources/views//cuentas/index.blade.php ENDPATH**/ ?>